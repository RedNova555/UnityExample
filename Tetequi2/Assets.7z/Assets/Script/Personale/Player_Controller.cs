using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Controller : MonoBehaviour
{
    //Guarda el movimiento vertical y horizontal
    private float _horizontalMove;
    private float _verticalMove;

    //almasena el input del jugador
    private Vector3 _inputJugador;

    //poder mover el charactercontroller del personaje
    public CharacterController player;

    //velocidad de movimiento del jugador
    public float playerSpeed = 10;

    //saber hacia donde mira la camara
    public Camera camara;

    //guardas las posiciones de la camara
    private Vector3 _camaraForward;
    private Vector3 _camaraRight;

    //saber direccion a la que se mueve el personaje en relacion con la camara
    private Vector3 _movePlayer;

    //gravedad del personaje
    public float gravity = 9.8f;

    //indica la velozidad de caida
    public float fallVelozity;

    private void Awake()
    {
        //tomamos el character controler del jugador
        player = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        //agarra y guarda el movimiento que el jugador este haciendo
        _horizontalMove = Input.GetAxis("Horizontal");
        _verticalMove = Input.GetAxis("Vertical");

        //guardamos los valores en el vector 3 (inputJugador), para despues estabilisarlo a que el maximo de movimiento sea 1
        _inputJugador = new Vector3(_horizontalMove, 0, _verticalMove);
        _inputJugador = Vector3.ClampMagnitude(_inputJugador, 1);

        //mandamos a llamar la dirreccion del la camara
        _CamDireccion();

        //seteamos la direccion de la camara
        _movePlayer = _inputJugador.x * _camaraRight + _inputJugador.z * _camaraForward;

        //modifica la velocidad del jugador (se hace de este modo para no afectar la gravedad 2 veces)
        _movePlayer = _movePlayer * playerSpeed;
        /*
        *Si no importa modificar la gravedad, se cambia en _Mover() esta linea asi player.Move(_movePlayer * player * Time.deltaTime);
        *y se elimina rastro del movimiento de la gravedad(variables, esta linea y el _SetGravity())
        */

        //actualiza para que siempre se mueba en relacion con la camara
        player.transform.LookAt(player.transform.position + _movePlayer);

        //mandamos a llamar a _SetGravity
        _SetGravity();

        //mandamos a llamar a Mover enviandole un vector 3
        _Mover();
    }

    //variable que ejecuta el movimiento
    void _Mover()
    {
        //actualizamos el movimiento del jugador
        player.Move(_movePlayer * Time.deltaTime);
    }

    //ejecuta la grabedad
    void _SetGravity()
    {
        //saber si esta tocando el suelo el jugador para aumentar o estabilicisar la velocidad de caida
        if (player.isGrounded)
        {
            //Una vez toque el suelo, su velocidad de caida se estabilisa
            fallVelozity = -gravity * Time.deltaTime;
        }
        else
        {
            //mientras no toque el suelo, su velocidad de caida acelerara.
            fallVelozity -= gravity * Time.deltaTime;
        }
        //a�adimos la velocidad de caida al jugador
        _movePlayer.y = fallVelozity;
    }

    //saber, asia donde mira la camara para el movimiento del personaje
    void _CamDireccion()
    {
        //le ingresamos los datos de la camara
        _camaraForward = camara.transform.forward;
        _camaraRight = camara.transform.right;

        //friseamos el movimiento en y
        _camaraForward.y = 0;
        _camaraRight.y = 0;

        //normalizamos la direccion para que sea mas ajustada
        _camaraForward = _camaraForward.normalized;
        _camaraRight = _camaraRight.normalized;
    }
}
